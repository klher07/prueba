# practi.cash
Proyecto Movil en PhoneGap de un sistema de pago movil adaptable para practisis

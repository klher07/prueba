<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","","blog") or die ("could not connect database");
?>
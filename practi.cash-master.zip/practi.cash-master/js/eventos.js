$(document).ready(function(){
//ESTE EVENTO ES PARA REDIRECCIONAR AL PULSAR LA FOTO PEQUEÑA
    $("#foto-peque").on("click",function(){

    	//alert("funciona");
    	window.location.href = "ajustes.html";
    })
});

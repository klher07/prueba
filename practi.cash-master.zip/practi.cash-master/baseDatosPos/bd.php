<?php 

  $con="host=localhost port=5432 dbname=practic password=123456 user=postgres";
  $cone=pg_connect($con);

?>